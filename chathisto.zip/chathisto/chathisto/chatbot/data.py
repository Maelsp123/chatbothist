
data =[
    {
        "question": "Quelle est la capitale de l'Égypte ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Égypte",
                "type": "LOC"
            }
        ],
        "answer": "La capitale de l'Égypte est Le Caire."
    },
    {
        "question": "Quand l'Algérie a-t-elle obtenu son indépendance ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "Algérie",
                "type": "LOC"
            },
            {
                "value": "indépendance",
                "type": "EVENT"
            }
        ],
        "answer": "L'Algérie a obtenu son indépendance en 1962."
    },
    {
        "question": "Qui était Nelson Mandela ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "Nelson Mandela",
                "type": "PERSON"
            }
        ],
        "answer": "Nelson Mandela était un leader sud-africain et un symbole de la lutte contre l'apartheid."
    },
    {
        "question": "Quelle organisation panafricaine a été fondée en 1963 ?",
        "intent": "demande_info_organisation",
        "entities": [
            {
                "value": "1963",
                "type": "DATE"
            },
            {
                "value": "organisation panafricaine",
                "type": "ORG"
            }
        ],
        "answer": "L'Organisation de l'Unité Africaine (OUA) a été fondée en 1963."
    },
    {
        "question": "Quels sont les pays traversés par le fleuve Nil ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Nil",
                "type": "LOC"
            }
        ],
        "answer": "Le Nil traverse plusieurs pays dont l'Ouganda, le Soudan et l'Égypte."
    },
    {
        "question": "Quand a eu lieu le génocide rwandais ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "génocide rwandais",
                "type": "EVENT"
            }
        ],
        "answer": "Le génocide rwandais a eu lieu en 1994."
    },
    {
        "question": "Quelle est la plus grande ville du Nigeria ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Nigeria",
                "type": "LOC"
            }
        ],
        "answer": "La plus grande ville du Nigeria est Lagos."
    },
    {
        "question": "Qui était Kwame Nkrumah ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "Kwame Nkrumah",
                "type": "PERSON"
            }
        ],
        "answer": "Kwame Nkrumah était le premier président du Ghana et un leader du mouvement pour l'indépendance de l'Afrique."
    },
    {
        "question": "Quel est le désert le plus vaste d'Afrique ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "désert",
                "type": "LOC"
            },
            {
                "value": "Afrique",
                "type": "LOC"
            }
        ],
        "answer": "Le désert le plus vaste d'Afrique est le Sahara."
    },
    {
        "question": "Quand l'Union Africaine a-t-elle été créée ?",
        "intent": "demande_info_organisation",
        "entities": [
            {
                "value": "Union Africaine",
                "type": "ORG"
            },
            {
                "value": "créée",
                "type": "EVENT"
            }
        ],
        "answer": "L'Union Africaine a été créée en 2002."
    },
    {
        "question": "Quelle est la capitale de l'Éthiopie ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Éthiopie",
                "type": "LOC"
            }
        ],
        "answer": "La capitale de l'Éthiopie est Addis-Abeba."
    },
    {
        "question": "Quand la guerre civile du Mozambique a-t-elle pris fin ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "guerre civile",
                "type": "EVENT"
            },
            {
                "value": "Mozambique",
                "type": "LOC"
            }
        ],
        "answer": "La guerre civile du Mozambique a pris fin en 1992."
    },
    {
        "question": "Quelle est la montagne la plus haute d'Afrique ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "montagne",
                "type": "LOC"
            },
            {
                "value": "Afrique",
                "type": "LOC"
            }
        ],
        "answer": "La montagne la plus haute d'Afrique est le Kilimandjaro."
    },
    {
        "question": "Qui était Hatshepsout ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "Hatshepsout",
                "type": "PERSON"
            }
        ],
        "answer": "Hatshepsout était une pharaonne de l'Égypte ancienne."
    },
    {
        "question": "Quelle est la capitale du Kenya ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Kenya",
                "type": "LOC"
            }
        ],
        "answer": "La capitale du Kenya est Nairobi."
    },
    {
        "question": "Quel événement marquant a eu lieu en Afrique du Sud en 1994 ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "Afrique du Sud",
                "type": "LOC"
            },
            {
                "value": "1994",
                "type": "DATE"
            }
        ],
        "answer": "En 1994, Nelson Mandela est devenu le premier président noir de l'Afrique du Sud."
    },
    {
        "question": "Quelle est la capitale de l'Algérie ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Algérie",
                "type": "LOC"
            }
        ],
        "answer": "La capitale de l'Algérie est Alger."
    },
    {
        "question": "Quand l'Égypte ancienne a-t-elle construit les pyramides de Gizeh ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "pyramides de Gizeh",
                "type": "MONUMENT"
            },
            {
                "value": "Égypte ancienne",
                "type": "LOC"
            }
        ],
        "answer": "Les pyramides de Gizeh ont été construites autour de 2580-2560 avant notre ère."
    },
    {
        "question": "Qui était Sundiata Keïta ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "Sundiata Keïta",
                "type": "PERSON"
            }
        ],
        "answer": "Sundiata Keïta était le fondateur de l'Empire du Mali au 13ème siècle."
    },
    {
        "question": "Quelle est la plus grande ville d'Éthiopie ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Éthiopie",
                "type": "LOC"
            }
        ],
        "answer": "La plus grande ville d'Éthiopie est Addis-Abeba."
    },
    {
        "question": "Quand l'Empire du Ghana a-t-il existé ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "Empire du Ghana",
                "type": "EVENT"
            }
        ],
        "answer": "L'Empire du Ghana a existé entre le 6ème et le 13ème siècle."
    },
    {
        "question": "Quelle est la capitale du Sénégal ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Sénégal",
                "type": "LOC"
            }
        ],
        "answer": "La capitale du Sénégal est Dakar."
    },
    {
        "question": "Qui a mené la rébellion Mau Mau au Kenya ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "rébellion Mau Mau",
                "type": "EVENT"
            },
            {
                "value": "Kenya",
                "type": "LOC"
            }
        ],
        "answer": "La rébellion Mau Mau a été menée par des groupes de Kikuyu contre la domination coloniale britannique."
    },
    {
        "question": "Quelle est la rivière la plus longue d'Afrique ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Afrique",
                "type": "LOC"
            }
        ],
        "answer": "La rivière la plus longue d'Afrique est le Nil."
    },
    {
        "question": "Quand le Maroc a-t-il obtenu son indépendance ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "Maroc",
                "type": "LOC"
            },
            {
                "value": "indépendance",
                "type": "EVENT"
            }
        ],
        "answer": "Le Maroc a obtenu son indépendance en 1956."
    },
    {
        "question": "Qui était Haïlé Sélassié ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "Haïlé Sélassié",
                "type": "PERSON"
            }
        ],
        "answer": "Haïlé Sélassié était l'empereur d'Éthiopie de 1930 à 1974."
    },
    {
        "question": "Quelle est la capitale du Ghana ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Ghana",
                "type": "LOC"
            }
        ],
        "answer": "La capitale du Ghana est Accra."
    },
    {
        "question": "Quand l'Empire du Mali a-t-il atteint son apogée ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "Empire du Mali",
                "type": "EVENT"
            }
        ],
        "answer": "L'Empire du Mali a atteint son apogée au 14ème siècle sous le règne de Mansa Musa."
    },
    {
        "question": "Quelle est la capitale de la Tanzanie ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Tanzanie",
                "type": "LOC"
            }
        ],
        "answer": "La capitale de la Tanzanie est Dodoma."
    },
    {
        "question": "Qui a dirigé la lutte pour l'indépendance de la Côte d'Ivoire ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "indépendance",
                "type": "EVENT"
            },
            {
                "value": "Côte d'Ivoire",
                "type": "LOC"
            }
        ],
        "answer": "Félix Houphouët-Boigny a dirigé la lutte pour l'indépendance de la Côte d'Ivoire."
    },
    {
        "question": "Quelle est la capitale de la Côte d'Ivoire ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Côte d'Ivoire",
                "type": "LOC"
            }
        ],
        "answer": "La capitale de la Côte d'Ivoire est Yamoussoukro."
    },
    {
        "question": "Quand la conférence de Berlin a-t-elle eu lieu ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "conférence de Berlin",
                "type": "EVENT"
            }
        ],
        "answer": "La conférence de Berlin a eu lieu de 1884 à 1885."
    },
    {
        "question": "Qui était Patrice Lumumba ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "Patrice Lumumba",
                "type": "PERSON"
            }
        ],
        "answer": "Patrice Lumumba était le premier Premier ministre de la République démocratique du Congo."
    },
    {
        "question": "Quelle est la capitale du Cameroun ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Cameroun",
                "type": "LOC"
            }
        ],
        "answer": "La capitale du Cameroun est Yaoundé."
    },
    {
        "question": "Quand l'Afrique du Sud a-t-elle mis fin à l'apartheid ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "Afrique du Sud",
                "type": "LOC"
            },
            {
                "value": "apartheid",
                "type": "EVENT"
            }
        ],
        "answer": "L'Afrique du Sud a officiellement mis fin à l'apartheid en 1994."
    },
    {
        "question": "Qui était Léopold Sédar Senghor ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "Léopold Sédar Senghor",
                "type": "PERSON"
            }
        ],
        "answer": "Léopold Sédar Senghor était un poète et le premier président du Sénégal."
    },
    {
        "question": "Quelle est la plus grande ville de l'Afrique du Sud ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Afrique du Sud",
                "type": "LOC"
            }
        ],
        "answer": "La plus grande ville de l'Afrique du Sud est Johannesburg."
    },
    {
        "question": "Quand la guerre d'indépendance de l'Algérie a-t-elle commencé ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "guerre d'indépendance",
                "type": "EVENT"
            },
            {
                "value": "Algérie",
                "type": "LOC"
            }
        ],
        "answer": "La guerre d'indépendance de l'Algérie a commencé en 1954."
    },
    {
        "question": "Quelle est la capitale de l'Ouganda ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Ouganda",
                "type": "LOC"
            }
        ],
        "answer": "La capitale de l'Ouganda est Kampala."
    },
    {
        "question": "Qui était Jomo Kenyatta ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "Jomo Kenyatta",
                "type": "PERSON"
            }
        ],
        "answer": "Jomo Kenyatta était le premier président du Kenya."
    },
    {
        "question": "Quelle est la plus grande ville du Maroc ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Maroc",
                "type": "LOC"
            }
        ],
        "answer": "La plus grande ville du Maroc est Casablanca."
    },
    {
        "question": "Quand l'Éthiopie a-t-elle été envahie par l'Italie ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "Éthiopie",
                "type": "LOC"
            },
            {
                "value": "Italie",
                "type": "LOC"
            }
        ],
        "answer": "L'Éthiopie a été envahie par l'Italie en 1935."
    },
    {
        "question": "Quelle est la capitale du Rwanda ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Rwanda",
                "type": "LOC"
            }
        ],
        "answer": "La capitale du Rwanda est Kigali."
    },
    {
        "question": "Qui était Kofi Annan ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "Kofi Annan",
                "type": "PERSON"
            }
        ],
        "answer": "Kofi Annan était un diplomate ghanéen et secrétaire général de l'ONU."
    },
    {
        "question": "Quelle est la capitale de la Libye ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Libye",
                "type": "LOC"
            }
        ],
        "answer": "La capitale de la Libye est Tripoli."
    },
    {
        "question": "Quand la guerre civile angolaise a-t-elle commencé ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "guerre civile",
                "type": "EVENT"
            },
            {
                "value": "Angola",
                "type": "LOC"
            }
        ],
        "answer": "La guerre civile angolaise a commencé en 1975."
    },
    {
        "question": "Quelle est la plus grande ville de l'Algérie ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Algérie",
                "type": "LOC"
            }
        ],
        "answer": "La plus grande ville de l'Algérie est Alger."
    },
    {
        "question": "Qui était Julius Nyerere ?",
        "intent": "demande_info_personnage",
        "entities": [
            {
                "value": "Julius Nyerere",
                "type": "PERSON"
            }
        ],
        "answer": "Julius Nyerere était le premier président de la Tanzanie."
    },
    {
        "question": "Quelle est la capitale du Zimbabwe ?",
        "intent": "demande_info_geographique",
        "entities": [
            {
                "value": "Zimbabwe",
                "type": "LOC"
            }
        ],
        "answer": "La capitale du Zimbabwe est Harare."
    },
    {
        "question": "Quand l'indépendance de la Zambie a-t-elle été proclamée ?",
        "intent": "demande_info_historique",
        "entities": [
            {
                "value": "Zambie",
                "type": "LOC"
            },
            {
                "value": "indépendance",
                "type": "EVENT"
            }
        ],
        "answer": "L'indépendance de la Zambie a été proclamée en 1964."
    },
    {
        "question": "Quelle est la capitale de la France ?",
        "intent": "demande_info_geographique",
        "entities": [
            {"value": "France", "type": "LOC"}
        ],
        "answer": "La capitale de la France est Paris."
    },
    {
        "question": "Quand a eu lieu la Révolution française ?",
        "intent": "demande_info_historique",
        "entities": [
            {"value": "Révolution française", "type": "EVENT"}
        ],
        "answer": "La Révolution française a eu lieu en 1789."
    },
    {
        "question": "Qui était Napoléon Bonaparte ?",
        "intent": "demande_info_personnage",
        "entities": [
            {"value": "Napoléon Bonaparte", "type": "PERSON"}
        ],
        "answer": "Napoléon Bonaparte était un militaire et empereur français."
    },
    {
        "question": "Quelle organisation a été fondée en 1945 ?",
        "intent": "demande_info_organisation",
        "entities": [
            {"value": "1945", "type": "DATE"}
        ],
        "answer": "L'Organisation des Nations Unies (ONU) a été fondée en 1945."
    },
    {
        "question": "Quels titres a eu Louis XIV ?",
        "intent": "demande_info_titre",
        "entities": [
            {"value": "Louis XIV", "type": "PERSON"}
        ],
        "answer": "Louis XIV a été Roi de France."
    },
    {
        "question": "Qui a écrit 'Les Misérables' ?",
        "intent": "demande_info_oeuvre",
        "entities": [
            {"value": "Les Misérables", "type": "WORK"}
        ],
        "answer": "'Les Misérables' a été écrit par Victor Hugo."
    },
    {
        "question": "Où se trouve la Tour Eiffel ?",
        "intent": "demande_info_monument",
        "entities": [
            {"value": "Tour Eiffel", "type": "MONUMENT"}
        ],
        "answer": "La Tour Eiffel se trouve à Paris."
    },
    {
        "question": "Quel est le plus long fleuve du monde ?",
        "intent": "demande_info_geographique",
        "entities": [],
        "answer": "Le plus long fleuve du monde est le Nil."
    },
    {
        "question": "Qui a découvert l'Amérique ?",
        "intent": "demande_info_historique",
        "entities": [
            {"value": "Amérique", "type": "LOC"}
        ],
        "answer": "Christophe Colomb a découvert l'Amérique en 1492."
    },
    {
        "question": "Quelle est la capitale de l'Italie ?",
        "intent": "demande_info_geographique",
        "entities": [
            {"value": "Italie", "type": "LOC"}
        ],
        "answer": "La capitale de l'Italie est Rome."
    }
]
