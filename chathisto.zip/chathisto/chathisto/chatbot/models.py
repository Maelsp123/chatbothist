from django.db import models


class User(models.Model):
    username = models.CharField(max_length=50, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username


class Question(models.Model):
    question_text = models.TextField()
    category = models.CharField(max_length=50)  # Par exemple, "géographie", "histoire"
    difficulty_level = models.CharField(max_length=50)  # Par exemple, "facile", "moyen", "difficile"
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.question_text


class Answer(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    answer_text = models.TextField()

    def __str__(self):
        return self.answer_text


class Intent(models.Model):
    intent_name = models.CharField(max_length=50, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.intent_name


class Entity(models.Model):
    entity_name = models.CharField(max_length=50)
    entity_value = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.entity_name}: {self.entity_value}"


class Conversation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    message_text = models.TextField()
    response_text = models.TextField()
    intent = models.ForeignKey(Intent, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username}: {self.message_text}"


