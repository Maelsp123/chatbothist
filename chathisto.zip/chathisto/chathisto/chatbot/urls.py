from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import UserViewSet, QuestionViewSet, AnswerViewSet, IntentViewSet, EntityViewSet, ConversationViewSet, chatbot_interaction

router = DefaultRouter()
router.register(r'users', UserViewSet)
router.register(r'questions', QuestionViewSet)
router.register(r'answers', AnswerViewSet)
router.register(r'intents', IntentViewSet)
router.register(r'entities', EntityViewSet)
router.register(r'conversations', ConversationViewSet)


urlpatterns = [
    path('', include(router.urls)),
    path('chatbot/', chatbot_interaction),
]
