import nltk
from nltk.corpus import stopwords
import spacy
from sklearn.pipeline import make_pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

# Télécharger les stopwords
nltk.download('stopwords')
nltk.download('punkt')

stop_words = set(stopwords.words('french'))

# Charger le modèle de langue française de spaCy
nlp = spacy.load('fr_core_news_sm')

def preprocess_text(text):
    tokens = nltk.word_tokenize(text)
    tokens = [word for word in tokens if word.lower() not in stop_words]
    return ' '.join(tokens)


# Exemple de données d'entraînement
train_data = ["Quelle est la capitale de la France?", "Quand a eu lieu la Révolution française?"]
train_labels = ["demande_info_geographique", "demande_info_historique"]

# Prétraiter les données
train_data = [preprocess_text(text) for text in train_data]

# Entraîner le modèle de classification
model = make_pipeline(TfidfVectorizer(), MultinomialNB())
model.fit(train_data, train_labels)

def classify_intent(text):
    text = preprocess_text(text)
    return model.predict([text])[0]

def extract_entities(text):
    doc = nlp(text)
    entities = [(ent.text, ent.label_) for ent in doc.ents]
    return entities

def manage_dialogue(intent, entities):
    if intent == "demande_info_geographique":
        country = [ent[0] for ent in entities if ent[1] == 'LOC']
        if country:
            return f"La capitale de {country[0]} est Paris."  # Vous pouvez ajouter une logique de base de données pour rechercher la capitale réelle
        else:
            return "Je ne connais pas ce pays."
    elif intent == "demande_info_historique":
        event = [ent[0] for ent in entities if ent[1] == 'DATE']
        if event:
            return f"L'événement a eu lieu en {event[0]}."  # Ajouter une logique pour obtenir la date exacte
        else:
            return "Je ne connais pas la date de cet événement."
    else:
        return "Je ne suis pas sûr de la réponse."

