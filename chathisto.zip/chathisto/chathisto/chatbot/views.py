from rest_framework import viewsets
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import User, Question, Answer, Intent, Entity, Conversation
from .serializers import UserSerializer, QuestionSerializer, AnswerSerializer, IntentSerializer, EntitySerializer, \
    ConversationSerializer
from .utils import classify_intent, extract_entities, manage_dialogue


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer


class QuestionViewSet(viewsets.ModelViewSet):
    queryset = Question.objects.all()
    serializer_class = QuestionSerializer


class AnswerViewSet(viewsets.ModelViewSet):
    queryset = Answer.objects.all()
    serializer_class = AnswerSerializer


class IntentViewSet(viewsets.ModelViewSet):
    queryset = Intent.objects.all()
    serializer_class = IntentSerializer


class EntityViewSet(viewsets.ModelViewSet):
    queryset = Entity.objects.all()
    serializer_class = EntitySerializer


class ConversationViewSet(viewsets.ModelViewSet):
    queryset = Conversation.objects.all()
    serializer_class = ConversationSerializer


@api_view(['POST'])
def chatbot_interaction(request):
    user_input = request.data.get('message')
    user_id = request.data.get('user_id')

    # Classifier l'intention
    intent_name = classify_intent(user_input)
    intent, created = Intent.objects.get_or_create(intent_name=intent_name)

    # Extraire les entités
    entities = extract_entities(user_input)

    # Gérer le dialogue et générer une réponse
    response_text = manage_dialogue(intent_name, entities)

    # Stocker la conversation
    conversation = Conversation.objects.create(
        user_id=user_id,
        message_text=user_input,
        response_text=response_text,
        intent=intent
    )

    # Sérialiser et retourner la réponse
    serializer = ConversationSerializer(conversation)
    return Response(serializer.data)
